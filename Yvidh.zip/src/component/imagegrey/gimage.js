import React, { Component } from "react";
import "./gimage.css";

export default class image extends Component {
  render() {
    return (
      <div className="mainContainer">
        <div className="container">
          <img src="./assets/background.jpg" alt="yvidh" />
        </div>
      </div>
    );
  }
}
