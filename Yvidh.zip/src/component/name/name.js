import React, { Component } from "react";
import "./name.css";

export default class name extends Component {
  render() {
    return (
      <div className="nameContainer">
        <div className="namey">
          <div className="nameinner">
            <img className="img4" src="/assets/vymal.png" alt="yv" />
          </div>
          <div className="nameinner">
            <img className="img1" src="/assets/yv.png" alt="yv" />
          </div>
          <div className="nameinner">
            <img className="img2" src="/assets/idh.png" alt="idh" />
          </div>
          <div className="nameinner">
            <img className="img3" src="/assets/vidhmala.png" alt="yv" />
          </div>
        </div>
      </div>
    );
  }
}
